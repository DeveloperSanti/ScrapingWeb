Integrar los Iframe
