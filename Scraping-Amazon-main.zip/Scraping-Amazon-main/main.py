from src.AmazonScraping import iniciar_scraping, extraer_productos, extraer_cantidad_paginas
from src.ExcelManager import limpiar_dataframe, guardar_dataframe_en_excel_por_paginas
from src.Fuji.get_data import get_datos_id
from src.SqlManager import guardar_datos_en_sql
from src.EmailManager import preparar_correo, enviar_correo
import sys
import os

#Agregar src al syspath
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), 'src')))


#Llamar las credenciales
data = get_datos_id('1')

def main():
    print("🔍 Iniciando scraping...")
    driver, wait = iniciar_scraping()
    datos = extraer_productos(driver, wait)
    total_paginas = extraer_cantidad_paginas(driver)
    print(f"✅ Scraping finalizado. Productos extraídos: {len(datos)}")

    print("💾 Procesando y guardando en Excel...")
    df = limpiar_dataframe(datos)
    guardar_dataframe_en_excel_por_paginas(df, total_paginas)

    print("📦 Guardando en SQL...")
    guardar_datos_en_sql(df, "tabla_faiber")

    print("📨 Enviando correo...")
    smtp_info, destinatarios, asunto, cuerpo, ruta_excel = preparar_correo()
    if smtp_info:
        enviar_correo(smtp_info, destinatarios, asunto, cuerpo, ruta_excel)
    else:
        print("Proceso de envío de correo cancelado por falta de credenciales")

#Ejecutar el main
if __name__ == "__main__":
    main()
