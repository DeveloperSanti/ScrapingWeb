# Librerías
from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import time

# Configuración del navegador
options = webdriver.ChromeOptions()
#options.add_experimental_option("detach", True)
options.add_argument("--start-maximized")
options.add_argument("--disable-blink-features=AutomationControlled")
options.add_argument(
    "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/114.0.0.0 Safari/537.36")


# Rutas XPATH
precioWhole = './/span[contains(@class,"a-price-whole")]'
precioFraction = './/span[@class="a-price-fraction"]'
precio2 = ".//div[@class='a-section a-spacing-none a-spacing-top-mini']//div[@class='a-row a-size-base a-color-secondary']//span[@class='a-color-base']"
calificacion = (
    ".//div[@class='a-row a-size-small']//span//a//i//span | .//div[@class='a-icon-row']//a//i//span"
)
xpath_titulo = (
    ".//div[contains(@class, 's-title-instructions-style')]//h2//span"
    " | .//div[contains(@class, 's-title-instructions-style')]//h2"
)
# Iniciar navegador y buscar producto
def iniciar_scraping():
    busqueda = input('Ingresa una busqueda: ')
    # Abrir navegador
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    url = "https://www.amazon.com/"
    driver.get(url)


    #Recargar pagína si no es valida
    max_reintentos = 10

    for intento in range(max_reintentos):
        try:
            wait = WebDriverWait(driver, 15)
            search_box = wait.until(EC.presence_of_element_located((By.ID, "twotabsearchtextbox")))
            search_box.send_keys(busqueda)
            search_box.send_keys(Keys.RETURN)
            break
        except TimeoutException:
            print(f"No se encontró el campo de búsqueda. Recargando... (Intento {intento + 1})")
            driver.refresh()
            time.sleep(2)
    else:
        print("No se pudo encontrar el campo después de varios intentos.")
    return driver, wait

# Cantidad de páginas
def extraer_cantidad_paginas(driver):
    try:
        paginas = driver.find_elements(By.XPATH, "//*[contains(@class,'s-pagination-item')]")

        num_paginas = [int(i.text) for i in paginas if i.text.isdigit()]

        total_pages = max(num_paginas, default=1)

        print("Total páginas:", total_pages)
        return total_pages
    except Exception as e:
        print(f"Error al extraer la cantidad de páginas: {e}")
        return 1

#Extraer titulo
def extraer_nombre(item):
    try:
        nombre = item.find_element(By.XPATH, xpath_titulo).text
        nombre = nombre[:45]
    except:
        nombre = "Error al extraer el nombre del producto."
    return nombre

#Extraer precio actual
def extraer_precio(item):
    try:
        whole = item.find_element(By.XPATH, precioWhole).text.strip().replace(",", "")
        fraction = item.find_element(By.XPATH, precioFraction).text.strip()
        precio_actual = f"{whole}.{fraction}"
    except:
        try:
            precio_actual = item.find_element(By.XPATH, precio2).text.strip().split("$")[1]
            precio_actual = precio_actual.replace(",", "")
        except:
            precio_actual = "N/A"
    return precio_actual

# Extraer precio completo sin descuento
def extraer_precio_full(item):
    try:
        precio_full = item.find_element(By.XPATH,
                                            ".//span[@class='a-price a-text-price']//span[@class='a-offscreen']")
        precio_full = precio_full.get_attribute("textContent").strip().split("$")[1]
        precio_full = precio_full.replace(",", "")
    except:
        precio_full = "N/A"
    return precio_full

# Calcular descuento
def extraer_descuento(precio_full, precio_actual):
    try:
        precio_actual = float(precio_actual) if precio_actual != "N/A" else 0
        precio_full = float(precio_full) if precio_full != "N/A" else 0
        descuento = precio_full - precio_actual
        if descuento < 0:
            descuento = 0
    except:
        return "Error"
    return descuento

#Calificación
def extraer_calificacion(item):
    try:
        calificacion_elem = item.find_element(By.XPATH, calificacion)
        return calificacion_elem.get_attribute("textContent").strip().split(" ")[0]
    except:
        return "N/A"

#Verificar si es patrocinado o general
def extraer_patrocinado(item):
    # PATROCINADOS
    try:
        # Verificar si el producto tiene la etiqueta "Sponsored" individualmente
        patrocinado = item.find_element(By.XPATH,
                                        ".//*[contains(text(),'Sponsored') or contains(text(),'Patrocinado') or contains(@id, 'dynamic-bb')]")
        result_patrocinado = "Patrocinado"
    except:

        try:
            # Buscar si el producto está dentro de un carrusel patrocinado
            contenedor_patrocinado = item.find_element(By.XPATH,
                                                       ".//ancestor::div[contains(@class,'s-include-content-margin s-border-bottom s-border-top-overlap s-widget-padding-bottom')]")

            # Si encontramos el contenedor, buscamos la etiqueta Sponsored dentro de él
            etiqueta_patrocinado = contenedor_patrocinado.find_elements(By.XPATH,
                                                                        ".//*[contains(text(),'Sponsored') or contains(text(),'Patrocinado')]")

            if etiqueta_patrocinado:
                result_patrocinado = "Patrocinado"
            else:
                result_patrocinado = "General"

        except:
            result_patrocinado = "General"
    return result_patrocinado

#Llamamos todas las funciones y armamos el dataframe
def extraer_productos(driver, wait):
        datos = []
        try:
            while True:
                wait.until(EC.presence_of_element_located((By.XPATH, './/div[contains(@class,"s-card-container")]')))
                main_products = driver.find_elements(By.XPATH, './/div[contains(@class,"s-card-container")]')
                all_products = main_products
                for prod in all_products:
                    info = {
                        "titulo": extraer_nombre(prod),
                        "precio_actual": extraer_precio(prod),
                        "precio_full": extraer_precio_full(prod),
                        "descuento": extraer_descuento(extraer_precio_full(prod), extraer_precio(prod)),
                        "calificacion": extraer_calificacion(prod),
                        "observacion": extraer_patrocinado(prod)
                    }
                    datos.append(info)

                print("Página procesada")
                #Pasar a la siguiente página
                try:
                    next_page = wait.until(EC.element_to_be_clickable((By.XPATH,
                                                                       '//a[contains(@class, "s-pagination-next") and not(contains(@class, "s-pagination-disabled"))]')))
                    driver.execute_script("arguments[0].click();", next_page)
                except:
                    print("No hay más páginas.")
                    break
        finally:
            print("🛑 Cerrando el navegador...")
    #driver.quit()
        return datos



