# Librerías
from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import time
import re

# Configuración del navegador
options = webdriver.ChromeOptions()
options.add_experimental_option("detach", True)
options.add_argument("--start-maximized")
options.add_argument("--disable-blink-features=AutomationControlled")
options.add_argument(
    "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/114.0.0.0 Safari/537.36")


# Rutas XPATH
precioWhole = './/span[contains(@class,"a-price-whole")]'
precioFraction = './/span[@class="a-price-fraction"]'
precio2 = ".//div[@class='a-section a-spacing-none a-spacing-top-mini']//div[@class='a-row a-size-base a-color-secondary']//span[@class='a-color-base']"
calificacion = (
    ".//div[@class='a-row a-size-small']//span//a//i//span | .//div[@class='a-icon-row']//a//i//span"
)
observacion = ".//div[@class='a-row a-spacing-micro']//span//a//span[@class='a-color-secondary']"
xpath_titulo = (
    ".//div[contains(@class, 's-title-instructions-style')]//h2//span"
    " | .//div[contains(@class, 's-title-instructions-style')]//h2"
    " | .//h2//span"
    " | .//h2"
)

def iniciar_scraping():
    busqueda = input('Ingresa una busqueda: ')
    # Abrir navegador
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    url = "https://www.amazon.com/"
    driver.get(url)


    #Recargar pagína si no es valida
    max_reintentos = 10

    for intento in range(max_reintentos):
        try:
            wait = WebDriverWait(driver, 15)
            search_box = wait.until(EC.presence_of_element_located((By.ID, "twotabsearchtextbox")))
            search_box.send_keys(busqueda)
            search_box.send_keys(Keys.RETURN)
            break
        except TimeoutException:
            print(f"No se encontró el campo de búsqueda. Recargando... (Intento {intento + 1})")
            driver.refresh()
            time.sleep(2)
    else:
        print("No se pudo encontrar el campo después de varios intentos.")
    return driver, wait

def extraer_cantidad_paginas(driver):
    try:
        paginas = driver.find_elements(By.XPATH, "//*[contains(@class,'s-pagination-item') and not(contains(@class,'dots'))]")

        num_paginas = [int(i.text) for i in paginas if i.text.isdigit()]

        total_pages = max(num_paginas, default=1)

        print("Total páginas:", total_pages)
        return total_pages
    except Exception as e:
        print(f"Error al extraer la cantidad de páginas: {e}")
        return 1


def extraer_nombre(item):
    try:
        nombre = item.find_element(By.XPATH, xpath_titulo).text
        nombre = nombre[:45]
    except:
        nombre = "N/A"
    return nombre

def extraer_precio(item):
    try:
        whole = item.find_element(By.XPATH, precioWhole).text.strip().replace(",", "")
        fraction = item.find_element(By.XPATH, precioFraction).text.strip()
        precio_actual = f"{whole}.{fraction}"
    except:
        try:
            precio_actual = item.find_element(By.XPATH, precio2).text.strip().split("$")[1]
            precio_actual = precio_actual.replace(",", "")
        except:
            precio_actual = "N/A"
    return precio_actual

def extraer_precio_full(item):
    try:
        precio_full = item.find_element(By.XPATH,
                                            ".//span[@class='a-price a-text-price']//span[@class='a-offscreen']")
        precio_full = precio_full.get_attribute("textContent").strip().split("$")[1]
        precio_full = precio_full.replace(",", "")
    except:
        precio_full = "N/A"
    return precio_full

def extraer_descuento(precio_full, precio_actual):
    try:
        precio_actual = float(precio_actual) if precio_actual != "N/A" else 0
        precio_full = float(precio_full) if precio_full != "N/A" else 0
        descuento = precio_full - precio_actual
        if descuento < 0:
            descuento = 0
    except:
        return "Error"
    return descuento

def extraer_calificacion(item):
    try:
        calificacion_elem = item.find_element(By.XPATH, calificacion)
        return calificacion_elem.get_attribute("textContent").strip().split(" ")[0]
    except:
        return "N/A"

def extraer_datos_desde_iframe(driver, iframe):
    producto = {}
    try:
        driver.switch_to.frame(iframe)
        wait = WebDriverWait(driver, 10)

        # Esperar a que el contenedor principal aparezca
        wait.until(EC.presence_of_element_located((By.ID, "dynamic-bb")))

        # Título
        try:
            titulo_elem = wait.until(EC.presence_of_element_located(
                (By.XPATH, "//*[@id='dynamic-bb']/div/div/div[1]")
            ))
            titulo = titulo_elem.get_attribute("textContent").strip()
            print("se guardo el titulo: ", titulo)
        except Exception as e:
            print("⚠️ No se pudo extraer el título:", e)
            titulo = "N/A"

        # Precio actual
        try:
            precio_entero = wait.until(EC.presence_of_element_located(
                (By.XPATH, "//*[@id='price-integer']"))).get_attribute("textContent").strip()
            precio_fraccion = driver.find_element(By.XPATH, "//*[@id='price-fraction']").get_attribute("textContent").strip()
            precio_actual = f"{precio_entero}.{precio_fraccion}"
            print("se guardo el precio actual: ", precio_actual)
        except :
            print("⚠️ No se pudo extraer el precio actual:", e)
            precio_actual = "N/A"

        # Precio full
        try:
            precio_full_raw = driver.find_element(By.XPATH, "//*[@id='dynamic-bb']/div/div/div[3]/div/div[2]").get_attribute("textContent").strip()
            precio_full = precio_full_raw.split("$")[1].replace(",", "")
            print("se guardo el precio full: ", precio_full)
        except:
            precio_full = "N/A"

        # Calificación
        # try:
        #     calificacion_elem = driver.find_element(By.XPATH, "//span[contains(@class,'a-icon-alt')]")
        #     calificacion = calificacion_elem.get_attribute("textContent").strip().split(" ")[0]
        # except:
        #     calificacion = "N/A"

        #descuento
        try:
            precio_actual = float(precio_actual) if precio_actual != "N/A" else 0
            precio_full = float(precio_full) if precio_full != "N/A" else 0
            descuento = precio_full - precio_actual
            if descuento < 0:
                descuento = 0
            print("se guardo el descuento: ", descuento)
        except:
            descuento = 0

        producto = {
            "titulo": titulo[:45],
            "precio_actual": precio_actual,
            "precio_full": precio_full,
            "descuento": descuento,
            "calificacion": "N/A",
            "observacion": "Patrocinado"
        }

    except Exception as e:
        print(f"❌ Error en iframe general: {e}")
    finally:
        driver.switch_to.default_content()

    return producto






def extraer_patrocinado(item):
    # PATROCINADOS
    try:
        # Verificar si el producto tiene la etiqueta "Sponsored" individualmente
        patrocinado = item.find_element(By.XPATH,
                                        ".//*[contains(text(),'Sponsored') or contains(text(),'Patrocinado') or contains(@id, 'dynamic-bb')]")
        result_patrocinado = "Patrocinado"
    except:

        try:
            # Buscar si el producto está dentro de un grupo patrocinado
            contenedor_patrocinado = item.find_element(By.XPATH,
                                                       ".//ancestor::div[contains(@class,'s-include-content-margin s-border-bottom s-border-top-overlap s-widget-padding-bottom')]")

            # Si encontramos el contenedor, buscamos la etiqueta Sponsored dentro de él
            etiqueta_patrocinado = contenedor_patrocinado.find_elements(By.XPATH,
                                                                        ".//*[contains(text(),'Sponsored') or contains(text(),'Patrocinado')]")

            if etiqueta_patrocinado:
                result_patrocinado = "Patrocinado"
            else:
                result_patrocinado = "General"

        except:
            result_patrocinado = "General"
    return result_patrocinado

def extraer_productos(driver, wait):
        datos = []
        while True:
            wait.until(EC.presence_of_element_located((By.XPATH, './/div[contains(@class,"s-card-container")]')))
            iframes = driver.find_elements(By.XPATH, "//iframe[@title='Anuncio patrocinado']")
            for iframe in iframes:
                producto_iframe = extraer_datos_desde_iframe(driver, iframe)
                if producto_iframe:
                    datos.append(producto_iframe)
            main_products = driver.find_elements(By.XPATH, './/div[contains(@class,"s-card-container")]')
            all_products = main_products
            for prod in all_products:
                info = {
                    "titulo": extraer_nombre(prod),
                    "precio_actual": extraer_precio(prod),
                    "precio_full": extraer_precio_full(prod),
                    "descuento": extraer_descuento(extraer_precio_full(prod), extraer_precio(prod)),
                    "calificacion": extraer_calificacion(prod),
                    "observacion": extraer_patrocinado(prod)
                }
                datos.append(info)

            print("Página procesada")
            try:
                next_page = wait.until(EC.element_to_be_clickable((By.XPATH,
                                                                   '//a[contains(@class, "s-pagination-next") and not(contains(@class, "s-pagination-disabled"))]')))
                driver.execute_script("arguments[0].click();", next_page)
            except:
                print("No hay más páginas.")
                break

        return datos



