#IMPORTAMOS LAS LIBRERIAS NECESARIAS

import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
import json
import re
import numpy as np
import os
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from sqlalchemy import create_engine
from src.Fuji.connection import connection
from sqlalchemy.exc import SQLAlchemyError
import smtplib
from email.message import EmailMessage
import mimetypes
import os
from src.email.enviar_correo import credenciales_data_smtp


#CREAMOS UNA VARIABLE PARA EL DRIVER

def iniciar_driver():
    driver = webdriver.Firefox()
    driver.get('https://www.amazon.com/')
    return driver


def realziar_busqueda(driver,keyword):
    # Buscamos el elemento de búsqueda por su ID
    search_resultado = driver.find_element(By.ID, "twotabsearchtextbox")
    search_resultado.click()

    # Enviamos la palabra clave para buscar
    search_resultado.send_keys(keyword)
    search_resultado.send_keys(Keys.RETURN)
    time.sleep(5)

    
def extraer_resultados_busqueda(driver):
    try:
        # Extraigo el texto de la página de resultados de búsqueda
        result_text = driver.find_element(By.XPATH, "//span[contains(text(),'results for')]").text
        print("Texto extraído:", result_text)

        # Convertimos el texto extraído a un número
        match = re.search(r'of (over )?([\d,]+)', result_text)
        if match:
            total_results = int(match.group(2).replace(',', ''))
        else:
            total_results = 0  # Valor por defecto si no se encuentra la coincidencia

        return total_results
    except Exception as e:
        print(f"Error al extraer resultados de búsqueda: {e}")
        return 0

def extraer_cantidad_paginas(driver):
    try:
        paginas = driver.find_elements(By.XPATH, "//*[contains(@class,'s-pagination-item') and not(contains(@class,'dots'))]")

        num_paginas = [int(i.text) for i in paginas if i.text.isdigit()]

        total_pages = max(num_paginas, default=1)  # Si no hay páginas, asumimos 1 por defecto

        print("Total páginas:", total_pages)
        return total_pages
    except Exception as e:
        print(f"Error al extraer la cantidad de páginas: {e}")
        return 1

def guardar_datos_en_json(total_results, total_pages, search_resultado, filename='resultado_amazon.json'):
    try:
        data = {
            "search_resultado": search_resultado,
            "total_results": total_results,
            "total_pages": total_pages,
        }
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)

        print(f"Datos guardados en {filename}")
    except Exception as e:
        print(f"Error al guardar datos en JSON: {e}")



def extraer_nombre(item):
    # NOMBRE
        try:
            nombre = item.find_element(By.XPATH, ".//div[@class='a-section a-spacing-none puis-padding-right-small s-title-instructions-style']//a//h2 | .//div[@class='a-section a-spacing-none a-spacing-top-small s-title-instructions-style']//a//h2").text
            nombre = nombre[:20]
        except:
            pass

        return nombre    


def extraer_precio_anterior(item):        

        # precio_anterior (tachado)
        try:
            precio_anterior = item.find_element(By.XPATH, ".//div[@class='a-section aok-inline-block']//span[@class='a-price a-text-price']//span[@class='a-offscreen']").get_attribute("textContent")
        except:
            precio_anterior = "N/A"

        return precio_anterior        

def extraer_precio_actual(item):
        # precio_actual
        try:
            entero = item.find_element(By.XPATH, ".//span[@class='a-price-whole']").text
            decimal = item.find_element(By.XPATH, ".//span[@class='a-price-fraction']").text
            precio_actual = f"{entero}.{decimal}"
            
        except:
            try:
                precio_actual = item.find_element(By.XPATH, ".//span[@class='a-color-base']").text
            except:
                precio_actual = "N/A"
        return precio_actual   
            
def extraer_calificacion(item):
        # CALIFICACIÓN
        calificacion = "N/A"

        try:
            calificacion_raw = item.find_element(By.XPATH, ".//div[@class='a-row a-size-small']//span[@class='a-declarative']//a").get_attribute("aria-label")
            calificacion = calificacion_raw.split(" ")[0]
        except:
            pass

        return calificacion


def extraer_patrocinado(item):
        # PATROCINADOS
        try:
            #Verificar si el producto tiene la etiqueta "Sponsored" individualmente
            patrocinado = item.find_element(By.XPATH, ".//*[contains(text(),'Sponsored') or contains(text(),'Patrocinado')]")
            result_patrocinado = "Patrocinado"
        except:

                try:
                # Buscar si el producto está dentro de un grupo patrocinado
                    contenedor_patrocinado = item.find_element(By.XPATH, ".//ancestor::div[contains(@class,'s-include-content-margin s-border-bottom s-border-top-overlap s-widget-padding-bottom')]")
                    
                # Si encontramos el contenedor, buscamos la etiqueta Sponsored dentro de él
                    etiqueta_patrocinado = contenedor_patrocinado.find_elements(By.XPATH, ".//*[contains(text(),'Sponsored') or contains(text(),'Patrocinado')]")

                    if etiqueta_patrocinado:  
                        result_patrocinado = "Patrocinado"
                    else:
                        result_patrocinado = "General"

                except:
                    result_patrocinado = "General"
        return result_patrocinado            

def extraer_descuento(precio_anterior, precio_actual):
    try:
        # Eliminar caracteres no numéricos como '$' y ',' y convertir a float
        precio_anterior = float(re.sub(r'[^\d.]', '', precio_anterior)) if precio_anterior != "N/A" else 0
        precio_actual = float(re.sub(r'[^\d.]', '', precio_actual)) if precio_actual != "N/A" else 0
        descuento = precio_anterior - precio_actual

        # Evitar descuentos negativos
        if descuento < 0:
            descuento = 0

    except:
        descuento = "N/A"  

    return round(descuento, 2) if isinstance(descuento, float) else descuento


def guardar_datos_en_lista(driver, total_pages):

    productos = []
    for _ in range(total_pages):
        print(f"📄 Procesando página {_ + 1} de {total_pages}...")
        time.sleep(3)
        items = driver.find_elements(By.XPATH, "//div[contains(@class,'s-main-slot')]//div[contains(@class,'puis-card-container')]")

        for item in items:
            producto_lista = {
                "nombre": extraer_nombre(item),
                "calificacion": extraer_calificacion(item),
                "precio_anterior": extraer_precio_anterior(item),
                "precio_actual": extraer_precio_actual(item),
                "observacion": extraer_patrocinado(item),
                "descuento": extraer_descuento(extraer_precio_anterior(item), extraer_precio_actual(item))
            }
            productos.append(producto_lista)
        # Navegar a la siguiente página 
        try:
            siguiente = driver.find_element(By.XPATH, "//a[contains(@class,'s-pagination-next')]")
            siguiente.click()
            time.sleep(3)  # Esperar a que cargue la siguiente página
        except:
            print("🚫 No hay más páginas disponibles.")
            break

    return productos

def imprimir_productos(partes):

    for i, df_parte in enumerate(partes):
        print(f"\n📄 Página {i+1}")
        print(df_parte)



def guardar_en_dataframe(productos):
    df = pd.DataFrame(productos)
    df["precio_actual"] = df["precio_actual"].str.replace(r'[^\d.]', '', regex=True)  # Eliminar símbolos
    df["precio_actual"] = pd.to_numeric(df["precio_actual"], errors="coerce")#convertimos la columna "precio_actual" a numerico
    df["precio_actual"] = np.where(df["precio_actual"] >= 50, df["precio_actual"].round(), df["precio_actual"])# Aplicar redondeo solo a los valores >= 50

    df["precio_anterior"] = df["precio_anterior"].str.replace(r'[^\d.]', '', regex=True)  # Eliminar símbolos
    df["precio_anterior"] = pd.to_numeric(df["precio_anterior"], errors="coerce")  # Convertir a float
    df["precio_anterior"] = df["precio_anterior"].fillna(df["precio_actual"])
    # Reemplazar NaN en "precio_anterior" con "precio_actual"

    df = df[df["nombre"].str.contains("iPhone", na=False)]
    df = df.sort_values(by='precio_actual', ascending=False) #Ordena los precios de mayor a menor

    return df

def dividir_en_partes_dataframe(df, total_pages):
    return list(np.array_split(df, total_pages))

def guardar_datos_en_excel(df, total_pages):
    with pd.ExcelWriter('DATAFRAME_PRODUCTOS.xlsx') as writer:
        # Guardar cada página en una hoja diferente
        for i, pagina in enumerate(dividir_en_partes_dataframe(df, total_pages)):
            pagina.to_excel(writer, sheet_name=f'Página_{i+1}', index=False)  
        print("Las páginas se han guardado correctamente en el archivo Excel✅.")
def abrir_excel():

        
    file_path = 'DATAFRAME_PRODUCTOS.xlsx'
    # Abrir el archivo en la consola de Windows
    if os.name == 'nt':  
        os.system(f'start excel "{file_path}"')


def guardar_datos_en_sql(df, nombre_tabla):
    conn = connection()
    if conn:
        cursor = conn.cursor()
    else:
        print("No se pudo establecer conexión a la base de datos.")
        return
    
    for index, row in df.iterrows():
        # Extraer los valores de cada columna
        try:
            nombre = str(row['nombre'])
        except:
            nombre = None
        
        try:
            calificacion = str(row['calificacion'])
        except:
            calificacion = None
        
        try:
            precio_anterior = str(row['precio_anterior'])
        except:
            precio_anterior = None
        
        try:
            precio_actual = str(row['precio_actual'])
        except:
            precio_actual = None
        
        try:
            observacion = str(row['observacion'])
        except:
            observacion = None
        
        try:
            descuento = str(row['descuento'])
        except:
            descuento = None

        try:
            cursor.execute(f"""
                INSERT INTO {nombre_tabla} (nombre, precio_anterior, precio_actual, calificacion, observacion, descuento)
                VALUES (?, ?, ?, ?, ?, ?)
            """, 
            nombre, 
            precio_anterior, 
            precio_actual, 
            calificacion, 
            observacion,
            descuento
            )
        except Exception as e:
            print(f"⚠️ Error en fila {index}: {e}")

    conn.commit()
    cursor.close()
    conn.close()
    print("✅ Datos insertados correctamente en la tabla SQL Server.")


# Función para enviar el correo electrónico

def enviar_correo(smtp_info, destinatarios, asunto, cuerpo, ruta_excel):
    try:
        # Crear el mensaje
        msg = EmailMessage()
        msg["Subject"] = asunto
        msg["From"] = smtp_info['user_smtp']
        msg["To"] = ", ".join(destinatarios)
        msg.set_content(cuerpo)

        # Adjuntar el archivo Excel
        if os.path.exists(ruta_excel):
            with open(ruta_excel, "rb") as f:
                contenido = f.read()
                mime_type, _ = mimetypes.guess_type(ruta_excel)
                maintype, subtype = mime_type.split("/")
                msg.add_attachment(contenido, maintype=maintype, subtype=subtype, filename=os.path.basename(ruta_excel))
        else:
            print("El archivo no fue encontrado:", ruta_excel)
            return

        # Conexión al servidor SMTP
        with smtplib.SMTP(smtp_info['server_smtp'], int(smtp_info['port_smtp'])) as smtp:
            smtp.starttls()  # Seguridad
            smtp.login(smtp_info['user_smtp'], smtp_info['pass_smtp'])
            smtp.send_message(msg)

        print("✅ Correo enviado exitosamente.")
        
    except Exception as e:
        print("❌ Error al enviar el correo:", e)

def preparar_correo():
    smtp_data = credenciales_data_smtp(id_unico=1)
    if smtp_data:
        smtp_info = {
            'server_smtp': smtp_data[0],
            'port_smtp': smtp_data[1],
            'user_smtp': smtp_data[2],
            'pass_smtp': smtp_data[3]
        }

    destinatarios = ['aprendiz.serviciosti@gruporeditos.com']
    asunto = 'Archivo Excel '
    cuerpo = 'Hola,\n\nAdjunto encontrarás el archivo solicitado.\n\nSaludos.'
    ruta_excel = r'C:\Users\aprendiz.funcional\Downloads\ID_PRACTICAS\DATAFRAME_PRODUCTOS.xlsx'

    return smtp_info, destinatarios, asunto, cuerpo, ruta_excel




