#IMPORTAMOS LAS LIBRERIAS NECESARIAS

import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
import json
import re
import numpy as np
import os
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


#CREAMOS UNA VARIABLE PARA EL DRIVER

def iniciar_driver():
    driver = webdriver.Firefox()
    driver.get('https://www.amazon.com/')
    return driver


def realziar_busqueda(driver,keyword):
    # Buscamos el elemento de búsqueda por su ID
    search_resultado = driver.find_element(By.ID, "twotabsearchtextbox")
    search_resultado.click()

    # Enviamos la palabra clave para buscar
    search_resultado.send_keys(keyword)
    search_resultado.send_keys(Keys.RETURN)
    time.sleep(5)

    
def extraer_resultados_busqueda(driver):
    try:
        # Extraigo el texto de la página de resultados de búsqueda
        result_text = driver.find_element(By.XPATH, "//span[contains(text(),'results for')]").text
        print("Texto extraído:", result_text)

        # Convertimos el texto extraído a un número
        match = re.search(r'of (over )?([\d,]+)', result_text)
        if match:
            total_results = int(match.group(2).replace(',', ''))
        else:
            total_results = 0  # Valor por defecto si no se encuentra la coincidencia

        return total_results
    except Exception as e:
        print(f"Error al extraer resultados de búsqueda: {e}")
        return 0

def extraer_cantidad_paginas(driver):
    try:
        paginas = driver.find_elements(By.XPATH, "//*[contains(@class,'s-pagination-item') and not(contains(@class,'dots'))]")

        num_paginas = [int(i.text) for i in paginas if i.text.isdigit()]

        total_pages = max(num_paginas, default=1)  # Si no hay páginas, asumimos 1 por defecto

        print("Total páginas:", total_pages)
        return total_pages
    except Exception as e:
        print(f"Error al extraer la cantidad de páginas: {e}")
        return 1

def guardar_datos_en_json(total_results, total_pages, search_resultado, filename='resultado_amazon.json'):
    try:
        data = {
            "search_resultado": search_resultado,
            "total_results": total_results,
            "total_pages": total_pages,
        }
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)

        print(f"Datos guardados en {filename}")
    except Exception as e:
        print(f"Error al guardar datos en JSON: {e}")



def extraer_nombre(item):
    # NOMBRE
        try:
            nombre = item.find_element(By.XPATH, ".//div[@class='a-section a-spacing-none puis-padding-right-small s-title-instructions-style']//a//h2 | .//div[@class='a-section a-spacing-none a-spacing-top-small s-title-instructions-style']//a//h2").text
            nombre = nombre[:20]
        except:
            pass

        return nombre    


def extraer_precio_anterior(item):        

        # PRECIO ANTERIOR (tachado)
        try:
            precio_anterior = item.find_element(By.XPATH, ".//div[@class='a-section aok-inline-block']//span[@class='a-price a-text-price']//span[@class='a-offscreen']").get_attribute("textContent")
        except:
            precio_anterior = "N/A"

        return precio_anterior        

def extraer_precio_actual(item):
        # PRECIO ACTUAL
        try:
            entero = item.find_element(By.XPATH, ".//span[@class='a-price-whole']").text
            decimal = item.find_element(By.XPATH, ".//span[@class='a-price-fraction']").text
            precio_actual = f"{entero}.{decimal}"
            
        except:
            try:
                precio_actual = item.find_element(By.XPATH, ".//span[@class='a-color-base']").text
            except:
                precio_actual = "N/A"
        return precio_actual   
            
def extraer_calificacion(item):
        # CALIFICACIÓN
        calificacion = "N/A"

        try:
            calificacion_raw = item.find_element(By.XPATH, ".//div[@class='a-row a-size-small']//span[@class='a-declarative']//a").get_attribute("aria-label")
            calificacion = calificacion_raw.split(" ")[0]
        except:
            pass

        return calificacion


def extraer_patrocinado(item):
        # PATROCINADOS

        try:
            #Verificar si el producto tiene la etiqueta "Sponsored" individualmente
            patrocinado = item.find_element(By.XPATH, ".//*[contains(text(),'Sponsored') or contains(text(),'Patrocinado')]")
            result_patrocinado = "Patrocinado"
        except:

                try:
                # Buscar si el producto está dentro de un grupo patrocinado
                    contenedor_patrocinado = item.find_element(By.XPATH, ".//ancestor::div[contains(@class,'s-include-content-margin s-border-bottom s-border-top-overlap s-widget-padding-bottom')]")
                    
                # Si encontramos el contenedor, buscamos la etiqueta Sponsored dentro de él
                    etiqueta_patrocinado = contenedor_patrocinado.find_elements(By.XPATH, ".//*[contains(text(),'Sponsored') or contains(text(),'Patrocinado')]")

                    if etiqueta_patrocinado:  
                        result_patrocinado = "Patrocinado"
                    else:
                        result_patrocinado = "General"

                except:
                    result_patrocinado = "General"
        return result_patrocinado            


def guardar_datos_en_lista(driver, total_pages):

    productos = []
    for _ in range(total_pages):
        print(f"📄 Procesando página {_ + 1} de {total_pages}...")
        time.sleep(3)
        items = driver.find_elements(By.XPATH, "//div[contains(@class,'s-main-slot')]//div[contains(@class,'puis-card-container')]")

        for item in items:
            producto_lista = {
                "nombre": extraer_nombre(item),
                "calificacion": extraer_calificacion(item),
                "precio anterior": extraer_precio_anterior(item),
                "precio actual": extraer_precio_actual(item),
                "patrocinado": extraer_patrocinado(item)
            }
            productos.append(producto_lista)
        # Navegar a la siguiente página 
        try:
            siguiente = driver.find_element(By.XPATH, "//a[contains(@class,'s-pagination-next')]")
            siguiente.click()
            time.sleep(3)  # Esperar a que cargue la siguiente página
        except:
            print("🚫 No hay más páginas disponibles.")
            break

    return productos

def imprimir_productos(partes):

    for i, df_parte in enumerate(partes):
        print(f"\n📄 Página {i+1}")
        print(df_parte)



def guardar_en_dataframe(productos):
    df = pd.DataFrame(productos)
    df["precio actual"] = df["precio actual"].str.replace(r'[^\d.]', '', regex=True)  # Eliminar símbolos
    df["precio actual"] = pd.to_numeric(df["precio actual"], errors="coerce")#convertimos la columna "Precio actual" a numerico
    df["precio actual"] = np.where(df["precio actual"] >= 50, df["precio actual"].round(), df["precio actual"])# Aplicar redondeo solo a los valores >= 50



    df["precio anterior"] = df["precio anterior"].str.replace(r'[^\d.]', '', regex=True)  # Eliminar símbolos
    df["precio anterior"] = pd.to_numeric(df["precio anterior"], errors="coerce")  # Convertir a float
    df["precio anterior"] = df["precio anterior"].fillna(df["precio actual"])
    # Reemplazar NaN en "Precio anterior" con "Precio actual"

    # Calcular el descuento (si Precio anterior == Precio actual, el descuento debe ser 0)
    df.insert(4, "descuento", df["precio anterior"] - df["precio actual"])
    df["descuento"] = np.where(df["descuento"] > 0, df["descuento"], 0)
    df["descuento"] = pd.to_numeric(df["descuento"])

    df = df[df["nombre"].str.contains("iPhone", na=False)]
    df = df.sort_values(by='precio actual', ascending=False) #Ordena los precios de mayor a menor

    return df

def dividir_en_partes_dataframe(df, total_pages):
    return list(np.array_split(df, total_pages))

def guardar_datos_en_excel(df, total_pages):
    with pd.ExcelWriter('DATAFRAME_PRODUCTOS.xlsx') as writer:
        # Guardar cada página en una hoja diferente
        for i, pagina in enumerate(dividir_en_partes_dataframe(df, total_pages)):
            pagina.to_excel(writer, sheet_name=f'Página_{i+1}', index=False)  
        print("Las páginas se han guardado correctamente en el archivo Excel✅.")
def abrir_excel():

        
    file_path = 'DATAFRAME_PRODUCTOS.xlsx'
    # Abrir el archivo en la consola de Windows
    if os.name == 'nt':  
        os.system(f'start excel "{file_path}"')



def main():
    driver = iniciar_driver()

    keyword = "iphone 15"
    realziar_busqueda(driver, keyword)
    total_results = extraer_resultados_busqueda(driver)
    total_pages = extraer_cantidad_paginas(driver)
    guardar_datos_en_json(total_pages, total_results, keyword)

    productos = guardar_datos_en_lista(driver, total_pages)
    df_total = guardar_en_dataframe(productos)
    dividir_en_partes_dataframe(df_total, total_pages)
    guardar_datos_en_excel(df_total, total_pages)
    abrir_excel()

    #print(imprimir_productos(partes))

if __name__ == "__main__":
    main()



