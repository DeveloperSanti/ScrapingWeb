from src.Fuji.get_data import get_datos_id
from src.scraping import iniciar_driver
from src.scraping import realziar_busqueda
from src.scraping import extraer_resultados_busqueda
from src.scraping import extraer_cantidad_paginas
from src.scraping import guardar_datos_en_json
from src.scraping import guardar_datos_en_lista
from src.scraping import guardar_en_dataframe
from src.scraping import dividir_en_partes_dataframe
from src.scraping import guardar_datos_en_excel
from src.scraping import guardar_datos_en_sql
from src.scraping import abrir_excel
from src.scraping import enviar_correo
from src.scraping import preparar_correo
import sys
import os

#importar el src
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), 'src')))

data = get_datos_id('1')

# Imprimir los datos obtenidos
# print(data)
def main():
    driver = iniciar_driver()

    keyword = "iphone 15"
    realziar_busqueda(driver, keyword)
    total_results = extraer_resultados_busqueda(driver)
    total_pages = extraer_cantidad_paginas(driver)
    guardar_datos_en_json(total_pages, total_results, keyword)

    productos = guardar_datos_en_lista(driver, total_pages)
    df_total = guardar_en_dataframe(productos)
    dividir_en_partes_dataframe(df_total, total_pages)
    guardar_datos_en_excel(df_total, total_pages)

    guardar_datos_en_sql(df_total, "tabla_faiber")
    abrir_excel()

    smtp_info, destinatarios, asunto, cuerpo, ruta_excel = preparar_correo()
    enviar_correo(smtp_info, destinatarios, asunto, cuerpo, ruta_excel)


if __name__ == "__main__":
    main()

